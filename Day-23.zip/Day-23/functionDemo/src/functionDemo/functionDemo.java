package functionDemo;
import java.util.function.Function;

public class functionDemo {
	public static void main(String[] args) {
		
		 Function<String, Integer> func = x -> x.length();
	       //Integer apply = func.apply("mkyong");//6   	      
	     Function< Integer, Integer> CubeValue = (a) -> (a*a*a);
	     Function< Integer, Integer> SquareValue = (a) -> (a*a);
	     Function<Integer, Integer> combo = CubeValue.andThen(SquareValue);
	     
	     System.out.println("The cube valu is : " + CubeValue.apply(12));
	     System.out.println("The square valu is : " + SquareValue.apply(6));
	     System.out.println("The string value length is : " + func.apply("mkyong"));
	     System.out.println("The combo valu is : " + combo.apply(2));
	}	
}

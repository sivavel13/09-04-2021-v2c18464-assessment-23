package employeeOTPDemo1;

import java.util.Random;
import java.util.function.Supplier;

public class employeeOTPDemo2 {

	public static void main(String[] args) {
		Supplier<String> EmpIdRandom1 = () -> {
		String EmpId1 = " ";
			for (int i = 0; i < 6; i++) {
				EmpId1 = EmpId1 + (int) (Math.random()*10);
			}
			return EmpId1;
		};
		System.out.println("employee 1:" + EmpIdRandom1.get());
		System.out.println("employee 2:" + EmpIdRandom1.get());
		System.out.println("employee 3:" + EmpIdRandom1.get());
		System.out.println("employee 4:" + EmpIdRandom1.get());

		Supplier<Integer> EmpIdRandom2 = () -> new Random().nextInt(10000000);
		
		System.out.println("employee 1:" + EmpIdRandom2.get());
		System.out.println("employee 2:" + EmpIdRandom2.get());
		System.out.println("employee 3:" + EmpIdRandom2.get());
		System.out.println("employee 4:" + EmpIdRandom2.get());
				
			}

		

	}



package employeeOTPDemo1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.function.Supplier;
class employee{
	
	String EmpName;
	int EmpId;
	public employee(String EmpName, int EmpId) {
		super();
		this.EmpName = EmpName;
		this.EmpId = EmpId;
	}
}
public class employeeOTPDemo1 {

	public static void main(String[] args) {			
		
		Supplier<Integer> EmpId = () -> new Random().nextInt(1000000);
		
		ArrayList<employee> emp = new ArrayList<employee>();
		emp.add(new employee ("Tom", EmpId.get()));
		emp.add(new employee ("Jerry", EmpId.get()));
		emp.add(new employee ("Jack", EmpId.get()));		
		
		Comparator<employee> NameComparator = (E1,E2) -> {
			return E1.EmpName.compareTo(E2.EmpName);
		};
		Collections.sort(emp, NameComparator);
		
		for( employee i : emp ) {
			System.out.println( i.EmpName + " " + i.EmpId );			
		}
	}
}



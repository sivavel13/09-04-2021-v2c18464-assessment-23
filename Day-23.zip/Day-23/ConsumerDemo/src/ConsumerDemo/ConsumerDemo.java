package ConsumerDemo;

import java.util.function.Consumer;

public class ConsumerDemo {

	public static void main(String[] args) {
		
		Consumer <String> StringCheck= (S1) -> {
			String S2 = S1.toLowerCase();
			System.out.println(S2);
			if (S2.contains("python")) {
				System.out.println("Hello world ! for python ");
			}
			else if (S2.contains("java")) {
				System.out.println("Hello world ! for java ");
			}
			else {
				System.out.println("I don't know about this....:(");
			}
		}; 
		
		StringCheck.accept("PYTHON");
		StringCheck.accept("Java");
		StringCheck.accept("MongoDB");
		
		Consumer <String> ContainCheck = C1 -> System.out.println(C1.contains("python"));
		ContainCheck.accept("python is very easy code");
	}
	
	

}

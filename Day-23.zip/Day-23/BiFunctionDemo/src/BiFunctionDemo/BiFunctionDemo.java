package BiFunctionDemo;

import java.util.function.BiFunction;

public class BiFunctionDemo {

	public static void main(String[] args) {
		
		BiFunction<String,String,String> AddString = (S1,S2) -> (S1.concat(S2));
		
			System.out.println("The concat value is : " + AddString.apply("Java" , "Spring"));
			
		BiFunction<Integer, Integer, Integer>  addNumber = (I1, I2) -> (I1 + I2);
		
			System.out.println("tHE adding vale is : " + addNumber.apply(1045, 2074));
			
		BiFunction<Integer, Integer, Integer> FindSize = (F1, F2) -> {
			if(F1 == F2) {
				System.out.println(" Two Equal Number");
			}
			else if(F1 > F2) {
				System.out.println("F1 is graterthan F2");
			}
			else {
				System.out.println("F2 IS grate than F1");
			}
			return 0;	
		};
		
		FindSize.apply(12, 100);
	
	}

}
